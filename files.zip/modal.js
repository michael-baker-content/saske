// ════════════════════════════════════════════
// MODAL — attack roll modal
// ════════════════════════════════════════════

let modalWeapon = null;   // current weapon object
let modalSource = null;   // 'player' | 'companion'
let currentMAP  = 0;      // 0 = 1st, -1 = 2nd, -2 = 3rd+
let modalIsCrit = false;  // critical hit toggle state

function openModal(idx, source) {
  const weapon = source === 'player' ? C.weapons[idx] : C.companion.attacks[idx];
  modalWeapon = weapon;
  modalSource = source;
  currentMAP  = 0;
  modalIsCrit = false;

  // Header
  document.getElementById('modal-weapon-name').textContent = weapon.name;

  // Attack modifier — apply active condition penalties
  const condPen = source === 'player'
    ? (S._condPenalties?.atk || 0)
    : (S._hakiCondPenalties?.atk || 0);
  const mod = weapon.attack - condPen;
  document.getElementById('modal-atk-mod').value = (mod >= 0 ? '+' : '') + mod;
  document.getElementById('modal-d20').value = '';
  document.getElementById('modal-atk-total').value = '';

  // MAP buttons — show agile penalties if weapon has Agile trait
  const isAgile = weapon.traits?.some(t => t.toLowerCase().includes('agile'));
  const map2 = document.getElementById('map-btn-2');
  map2.textContent = isAgile ? '2nd attack (−4)' : '2nd attack (−5)';

  // Reset MAP selection and crit toggle
  document.querySelectorAll('.map-btn').forEach(b => b.classList.remove('active'));
  document.querySelector('.map-btn').classList.add('active');
  const critTog = document.getElementById('crit-toggle-btn');
  if (critTog) critTog.classList.remove('active');

  // Prey toggle row
  const hasPrey = !!S.prey;
  const preyRow = document.getElementById('prey-bonus-row');
  preyRow.style.display = hasPrey ? 'block' : 'none';
  if (hasPrey) {
    document.getElementById('prey-bonus-label').textContent = '🎯 ' + S.prey;
    document.getElementById('prey-tog').classList.add('on');
  }
  const precRow = document.getElementById('precision-row');
  precRow.style.display = hasPrey ? 'flex' : 'none';
  document.getElementById('modal-precision-die').value = '';

  // Build damage inputs from structured damage_rolls
  buildDamageInputs(false);

  // Hide results
  document.getElementById('result-grid').style.display = 'none';

  // Open
  document.getElementById('atk-modal-backdrop').classList.add('open');
  setTimeout(() => document.getElementById('modal-d20').focus(), 80);
}

// ── Build damage input rows ─────────────────────────────────────────
function buildDamageInputs(isCrit) {
  const weapon = modalWeapon;
  if (!weapon) return;

  const rolls   = weapon.damage_rolls || parseDamageToRolls(weapon.damage);
  const bonus   = weapon.damage_bonus || 0;
  const bonusLbl = weapon.damage_bonus_label || '';
  const abilMod = weapon.ability_mod;
  const crits   = weapon.crit_additions || [];
  const inputsEl = document.getElementById('modal-dmg-inputs');

  // Resolve ability modifier value
  let abilVal = 0;
  if (abilMod) {
    const attrs = modalSource === 'companion'
      ? C.companion.attributes
      : C.attributes;
    abilVal = attrs[abilMod.stat] ?? 0;
    if (abilMod.divisor) abilVal = Math.floor(abilVal / abilMod.divisor);
  }

  // On a crit, weapon dice count doubles; bonus and ability_mod also double
  const critMult  = isCrit ? 2 : 1;
  const totalBonus = (bonus + abilVal) * critMult;

  let html = '';

  // One input per damage_roll group
  rolls.forEach((roll, i) => {
    const diceCount = roll.dice * critMult;
    const facesMax  = roll.faces;
    const minVal    = 1;   // min single die value
    const maxVal    = facesMax; // max single die value (user enters one die, we multiply)
    const labelParts = [diceCount + 'd' + facesMax, roll.type];
    if (roll.label) labelParts.push('(' + roll.label + ')');

    html += '<div class="modal-die-group">'
          + '<div class="modal-input-label">' + diceCount + 'd' + facesMax + ' ' + roll.type + '</div>'
          + '<input class="modal-input" type="number" id="modal-dmg-' + i + '" '
          +   'placeholder="—" min="' + minVal + '" max="' + maxVal + '" '
          +   'data-count="' + diceCount + '" data-faces="' + facesMax + '" '
          +   'data-type="' + roll.type + '" data-category="' + roll.category + '"/>'
          + '</div>';
    if (i < rolls.length - 1) {
      html += '<div class="modal-plus">+</div>';
    }
  });

  // Flat bonus row (item + weapon spec + ability mod combined)
  if (totalBonus !== 0) {
    const bonusLabel = buildBonusLabel(bonus, bonusLbl, abilMod, abilVal, critMult);
    html += '<div class="modal-plus">+</div>'
          + '<div class="modal-die-group">'
          + '<div class="modal-input-label">' + bonusLabel + '</div>'
          + '<div class="modal-input modal-flat-bonus" id="modal-flat-bonus">' + (totalBonus > 0 ? '+' : '') + totalBonus + '</div>'
          + '</div>';
  }

  // Crit additions (deadly, fatal — not doubled)
  if (isCrit && crits.length) {
    crits.forEach((crit, ci) => {
      html += '<div class="modal-plus" style="color:var(--red-b)">+</div>'
            + '<div class="modal-die-group">'
            + '<div class="modal-input-label" style="color:var(--red-b)">' + crit.dice + 'd' + crit.faces + ' ' + crit.type + ' (' + crit.label + ')</div>'
            + '<input class="modal-input" type="number" id="modal-crit-' + ci + '" '
            +   'placeholder="—" min="1" max="' + crit.faces + '" '
            +   'data-count="' + crit.dice + '" data-faces="' + crit.faces + '" '
            +   'data-type="' + crit.type + '" data-category="' + crit.category + '"/>'
            + '</div>';
    });
  }

  inputsEl.innerHTML = html;
}

function buildBonusLabel(bonus, bonusLbl, abilMod, abilVal, critMult) {
  const parts = [];
  if (bonus)   parts.push('+' + bonus + (bonusLbl ? ' ' + bonusLbl : ''));
  if (abilVal) parts.push((abilVal > 0 ? '+' : '') + abilVal + ' ' + (abilMod?.label || ''));
  if (critMult === 2) return '×2 (' + parts.join(', ') + ')';
  return parts.join(' ');
}

// ── Fallback: parse "2d6+3 P" string if no damage_rolls ────────────
function parseDamageToRolls(str) {
  if (!str) return [];
  const m = str.match(/^(\d+)d(\d+)([+-]\d+)?\s*(\S+)?/);
  if (!m) return [];
  return [{ dice: parseInt(m[1]), faces: parseInt(m[2]), type: m[4] || '', category: 'weapon', label: '' }];
}

// ── Crit toggle ─────────────────────────────────────────────────────
function toggleCrit() {
  modalIsCrit = !modalIsCrit;
  const btn = document.getElementById('crit-toggle-btn');
  if (btn) btn.classList.toggle('active', modalIsCrit);
  buildDamageInputs(modalIsCrit);
  document.getElementById('result-grid').style.display = 'none';
}

// ── Prey toggle ─────────────────────────────────────────────────────
function togglePreyAttack() {
  const tog = document.getElementById('prey-tog');
  const isOn = tog.classList.toggle('on');
  document.getElementById('precision-row').style.display = isOn ? 'flex' : 'none';
  if (!isOn) document.getElementById('modal-precision-die').value = '';
  document.getElementById('result-grid').style.display = 'none';
}

// ── Modal open/close ────────────────────────────────────────────────
function closeModal(e) {
  if (e.target === document.getElementById('atk-modal-backdrop')) closeModalDirect();
}
function closeModalDirect() {
  document.getElementById('atk-modal-backdrop').classList.remove('open');
  document.getElementById('result-grid').style.display = 'none';
}

// ── MAP ─────────────────────────────────────────────────────────────
function setMAP(tier, btn) {
  currentMAP = tier;
  document.querySelectorAll('.map-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  updateAtkTotal();
}

function effectiveMAP() {
  if (currentMAP === 0) return 0;
  const isAgile = modalWeapon?.traits?.some(t => t.toLowerCase().includes('agile'));
  if (currentMAP === -1) return isAgile ? -4 : -5;
  return isAgile ? -8 : -10;
}

function updateAtkTotal() {
  const d20 = parseInt(document.getElementById('modal-d20').value);
  if (isNaN(d20)) { document.getElementById('modal-atk-total').value = ''; return; }
  const condPen = modalSource === 'player'
    ? (S._condPenalties?.atk || 0)
    : (S._hakiCondPenalties?.atk || 0);
  const mod = modalWeapon.attack - condPen;
  const map = effectiveMAP();
  document.getElementById('modal-atk-total').value = d20 + mod + map;
}

document.addEventListener('input', e => {
  if (e.target.id === 'modal-d20') updateAtkTotal();
});

// ── Calculate results ───────────────────────────────────────────────
function calcResults() {
  const d20 = parseInt(document.getElementById('modal-d20').value);
  if (isNaN(d20)) { alert('Enter your d20 roll first.'); return; }

  const condPen = modalSource === 'player'
    ? (S._condPenalties?.atk || 0)
    : (S._hakiCondPenalties?.atk || 0);
  const mod = modalWeapon.attack - condPen;
  const map = effectiveMAP();
  const atkTotal = d20 + mod + map;

  let atkBreak = 'd20(' + d20 + ') + mod(' + (mod >= 0 ? '+' + mod : mod) + ')';
  if (map !== 0) atkBreak += ' + MAP(' + map + ')';

  // Damage — iterate over all dice inputs
  let dmgTotal = 0;
  const breakParts = [];

  // Main weapon dice
  const rolls = modalWeapon.damage_rolls || parseDamageToRolls(modalWeapon.damage);
  rolls.forEach((roll, i) => {
    const inp = document.getElementById('modal-dmg-' + i);
    const singleDie = parseInt(inp?.value);
    if (isNaN(singleDie)) return;
    const diceCount = roll.dice * (modalIsCrit ? 2 : 1);
    const rolled    = singleDie * diceCount;
    dmgTotal += rolled;
    breakParts.push(diceCount + '×' + singleDie + ' ' + roll.type);
  });

  // Flat bonus (already computed and displayed — read from DOM element)
  const flatEl = document.getElementById('modal-flat-bonus');
  if (flatEl) {
    const flatVal = parseInt(flatEl.textContent);
    if (!isNaN(flatVal) && flatVal !== 0) {
      dmgTotal += flatVal;
      breakParts.push((flatVal > 0 ? '+' : '') + flatVal + ' flat');
    }
  }

  // Crit additions (deadly etc.)
  if (modalIsCrit) {
    const crits = modalWeapon.crit_additions || [];
    crits.forEach((crit, ci) => {
      const inp = document.getElementById('modal-crit-' + ci);
      const singleDie = parseInt(inp?.value);
      if (isNaN(singleDie)) return;
      const rolled = singleDie * crit.dice;
      dmgTotal += rolled;
      breakParts.push(crit.dice + '×' + singleDie + ' ' + crit.type + ' (' + crit.label + ')');
    });
  }

  // Precision die (Hunt Prey)
  const preyTogOn = document.getElementById('prey-tog')?.classList.contains('on');
  if (preyTogOn && document.getElementById('precision-row')?.style.display !== 'none') {
    const pv = parseInt(document.getElementById('modal-precision-die').value);
    if (!isNaN(pv)) {
      dmgTotal += pv;
      breakParts.push('prec(' + pv + ')');
    }
  }

  // Display
  document.getElementById('res-atk').textContent = atkTotal;
  document.getElementById('res-atk-break').textContent = atkBreak;

  if (breakParts.length) {
    document.getElementById('res-dmg').textContent = dmgTotal;
    document.getElementById('res-dmg-break').textContent = breakParts.join(' + ');
  } else {
    document.getElementById('res-dmg').textContent = '—';
    document.getElementById('res-dmg-break').textContent = 'Enter dice above';
  }

  document.getElementById('result-grid').style.display = 'grid';
}

// ── Keyboard shortcuts ──────────────────────────────────────────────
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') closeModalDirect();
  if (e.key === 'Enter' && document.getElementById('atk-modal-backdrop').classList.contains('open')) calcResults();
});
